package com.alfy.cleaner

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Semua perintah root lewat `su -M -c` (Runtime.exec): -M (mount master) menembus isolasi
 * mount namespace Magisk sehingga /data/data aplikasi lain terlihat. libsu tidak dipakai di sini
 * karena shell-nya berjalan di namespace terisolasi (rm/du tidak berefek).
 */
class RootManager {

    private companion object {
        const val TAG = "RootManager"
        val PACKAGE_REGEX = Regex("^[A-Za-z0-9_.]+$")
    }

    /** Hasil eksekusi: exit code dan stdout. exit code -1 jika gagal dijalankan. */
    private class SuResult(val code: Int, val out: String)

    private fun runSu(cmd: String): SuResult =
        try {
            val process = Runtime.getRuntime().exec(arrayOf("su", "-M", "-c", cmd))
            val out = process.inputStream.bufferedReader().use { it.readText() }
            val err = process.errorStream.bufferedReader().use { it.readText() }
            val code = process.waitFor()
            process.destroy()
            if (err.isNotBlank()) Log.d(TAG, "ERR: $err")
            SuResult(code, out.trim())
        } catch (e: Exception) {
            Log.e(TAG, "su gagal: ${e.message}")
            SuResult(-1, "")
        }

    /** Cek akses root (memunculkan pop-up Superuser bila belum diizinkan). Mengembalikan true jika uid=0. */
    suspend fun checkRoot(): Boolean = withContext(Dispatchers.IO) { requestRoot() }

    /** Meminta izin root (memunculkan pop-up Superuser). Blocking: panggil dari Dispatchers.IO. */
    fun requestRoot(): Boolean = runSu("id").out.contains("uid=0")

    /**
     * Setara "Hapus cache" manual di Info Aplikasi: isi cache, code_cache, dan cache eksternal
     * (termasuk file tersembunyi). Foldernya dipertahankan. Blocking: panggil dari Dispatchers.IO.
     */
    fun clearCache(packageName: String): Boolean {
        if (!PACKAGE_REGEX.matches(packageName)) return false
        return runSu(clearCmd(packageName)).code == 0
    }

    /**
     * Pembersihan agresif: semua yang dihapus clearCache, ditambah file berekstensi tmp dan log.
     * Folder `databases` dan `shared_prefs` TIDAK PERNAH disentuh.
     */
    fun clearCacheAggressive(packageName: String): Boolean {
        if (!PACKAGE_REGEX.matches(packageName)) return false

        val rm = runSu(clearCmd(packageName))
        val find = runSu(
            "find /data/data/$packageName " +
                "\\( -name databases -o -name shared_prefs \\) -prune -o " +
                "-type f \\( -name '*.tmp' -o -name '*.log' \\) " +
                "! -path '*/databases/*' ! -path '*/shared_prefs/*' " +
                "-exec rm -f {} +"
        )
        return rm.code == 0 && find.code == 0
    }

    /** Hapus isi (termasuk dotfile) tiap folder cache; `rm -rf` tidak error bila glob kosong. */
    private fun clearCmd(pkg: String): String =
        listOf(
            "/data/data/$pkg/cache",
            "/data/data/$pkg/code_cache",
            "/sdcard/Android/data/$pkg/cache",
            "/sdcard/Android/data/$pkg/code_cache"
        ).joinToString("; ") { d -> "rm -rf $d/* $d/.[!.]* $d/..?* 2>/dev/null" } + "; true"
}
