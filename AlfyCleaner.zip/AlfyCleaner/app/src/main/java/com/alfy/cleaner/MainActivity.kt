package com.alfy.cleaner

import android.app.TimePickerDialog
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

private val AmoledColors = darkColorScheme(
    primary = Color(0xFF80CBC4),
    onPrimary = Color.Black,
    background = Color.Black,
    onBackground = Color.White,
    surface = Color.Black,
    onSurface = Color.White,
    primaryContainer = Color(0xFF00695C),
    onPrimaryContainer = Color.White
)

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = AmoledColors) {
                MainScreen(viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MainScreen(viewModel: MainViewModel) {
    val state by viewModel.uiState.collectAsState()
    val context = LocalContext.current

    var dialogLevel by remember { mutableStateOf<StatusBahaya?>(null) }

    dialogLevel?.let { level ->
        val isDanger = level == StatusBahaya.BAHAYA
        val confirmColor = if (isDanger) Color(0xFFF44336) else Color(0xFFFFC107)
        val confirmTextColor = if (isDanger) Color.White else Color.Black
        AlertDialog(
            onDismissRequest = { dialogLevel = null },
            containerColor = Color(0xFF121212),
            titleContentColor = Color.White,
            textContentColor = Color.White,
            title = { Text(if (isDanger) "🔴 Bahaya" else "🟡 Peringatan") },
            text = {
                Text(
                    if (isDanger) "PERINGATAN KERAS! Ini aplikasi inti. Hapus cache-nya?"
                    else "Aplikasi sistem terpilih. Tetap bersihkan?"
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        dialogLevel = null
                        viewModel.executeClearCache(context)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = confirmColor,
                        contentColor = confirmTextColor
                    )
                ) {
                    Text("Bersihkan")
                }
            },
            dismissButton = {
                TextButton(onClick = { dialogLevel = null }) {
                    Text("Batal", color = Color.White)
                }
            }
        )
    }

    LaunchedEffect(Unit) {
        viewModel.messages.collect { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        containerColor = Color.Black,
        topBar = {
            TopAppBar(
                title = { Text("AlfyCleaner") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Black,
                    titleContentColor = Color.White
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    val selected = state.apps.filter { it.packageName in state.selectedPackages }
                    when {
                        state.selectedPackages.isEmpty() ->
                            Toast.makeText(context, "Pilih aplikasi dulu", Toast.LENGTH_SHORT).show()
                        selected.any { it.statusBahaya == StatusBahaya.BAHAYA } ->
                            dialogLevel = StatusBahaya.BAHAYA
                        selected.any { it.statusBahaya == StatusBahaya.PERINGATAN } ->
                            dialogLevel = StatusBahaya.PERINGATAN
                        else -> viewModel.executeClearCache(context)
                    }
                },
                icon = { Icon(Icons.Default.Delete, contentDescription = null) },
                text = { Text("Bersihkan Cache") }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Button(
                onClick = { viewModel.onCheckRootClicked() },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text("Cek Akses Root")
            }

            AutoClearCard()

            TabRow(
                selectedTabIndex = if (state.isAggressiveMode) 1 else 0,
                containerColor = Color.Black,
                contentColor = MaterialTheme.colorScheme.primary
            ) {
                Tab(
                    selected = !state.isAggressiveMode,
                    onClick = { viewModel.setAggressiveMode(false) },
                    text = { Text("Mode Biasa") }
                )
                Tab(
                    selected = state.isAggressiveMode,
                    onClick = { viewModel.setAggressiveMode(true) },
                    text = { Text("Mode Agresif") }
                )
            }
            Text(
                text = if (state.isAggressiveMode) "Sapu bersih sisa file sementara" else "Hapus cache standar",
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 96.dp),
                verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
            ) {
                items(state.apps, key = { it.packageName }) { app ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF121212))
                    ) {
                        Row(
                            modifier = Modifier.padding(end = 16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = app.packageName in state.selectedPackages,
                                onCheckedChange = { viewModel.toggleSelection(app.packageName) }
                            )
                            Text(
                                text = "${app.packageName}\n%.2f MB".format(app.ukuranCache / 1024.0),
                                modifier = Modifier.padding(vertical = 16.dp),
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AutoClearCard() {
    val context = LocalContext.current
    val manager = remember { AutoClearManager(context) }
    var enabled by remember { mutableStateOf(manager.isEnabled()) }
    var hour by remember { mutableStateOf(manager.getHour()) }
    var minute by remember { mutableStateOf(manager.getMinute()) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 16.dp, bottom = 8.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF121212))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween
            ) {
                Text("Aktifkan Auto-Clear", color = Color.White)
                Switch(
                    checked = enabled,
                    onCheckedChange = { checked ->
                        enabled = checked
                        manager.setEnabled(checked)
                        if (checked) manager.schedule(hour, minute) else manager.cancel()
                    }
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween
            ) {
                Text("Jam: %02d:%02d".format(hour, minute), color = Color.White)
                TextButton(onClick = {
                    TimePickerDialog(
                        context,
                        { _, h, m ->
                            hour = h
                            minute = m
                            manager.setTime(h, m)
                            if (enabled) manager.schedule(h, m)
                        },
                        hour,
                        minute,
                        true
                    ).show()
                }) {
                    Text("Pilih Jam")
                }
            }
        }
    }
}
