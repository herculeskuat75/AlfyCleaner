package com.alfy.cleaner

import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.topjohnwu.superuser.Shell

private val AmoledColors = darkColorScheme(
    primary = Color(0xFF80CBC4),
    onPrimary = Color.Black,
    background = Color.Black,
    onBackground = Color.White,
    surface = Color.Black,
    onSurface = Color.White,
    primaryContainer = Color(0xFF00695C),
    onPrimaryContainer = Color.White
)

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inisialisasi libsu sebelum UI dimuat.
        Shell.enableVerboseLogging = (applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
        // setDefaultBuilder hanya boleh dipanggil sebelum shell utama dibuat (mis. saat Activity dibuat ulang).
        runCatching {
            Shell.setDefaultBuilder(
                Shell.Builder.create()
                    .setFlags(Shell.FLAG_REDIRECT_STDERR)
                    .setTimeout(10)
            )
        }

        setContent {
            MaterialTheme(colorScheme = AmoledColors) {
                MainScreen(viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MainScreen(viewModel: MainViewModel) {
    val state by viewModel.uiState.collectAsState()
    val context = LocalContext.current

    var dialogLevel by remember { mutableStateOf<StatusBahaya?>(null) }

    dialogLevel?.let { level ->
        val isDanger = level == StatusBahaya.BAHAYA
        val confirmColor = if (isDanger) Color(0xFFF44336) else Color(0xFFFFC107)
        val confirmTextColor = if (isDanger) Color.White else Color.Black
        AlertDialog(
            onDismissRequest = { dialogLevel = null },
            containerColor = Color(0xFF121212),
            titleContentColor = Color.White,
            textContentColor = Color.White,
            title = { Text(if (isDanger) "🔴 Bahaya" else "🟡 Peringatan") },
            text = {
                Text(
                    if (isDanger) "PERINGATAN KERAS! Ini aplikasi inti. Hapus cache-nya?"
                    else "Aplikasi sistem terpilih. Tetap bersihkan?"
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        dialogLevel = null
                        viewModel.executeClearCache(context)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = confirmColor,
                        contentColor = confirmTextColor
                    )
                ) {
                    Text("Bersihkan")
                }
            },
            dismissButton = {
                TextButton(onClick = { dialogLevel = null }) {
                    Text("Batal", color = Color.White)
                }
            }
        )
    }

    LaunchedEffect(Unit) {
        viewModel.messages.collect { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
        }
    }

    val visibleApps = remember(state.apps, state.searchQuery, state.filter, state.sortBySize) {
        state.visibleApps
    }

    Scaffold(
        containerColor = Color.Black,
        topBar = {
            TopAppBar(
                title = { Text("AlfyCleaner") },
                actions = {
                    IconButton(onClick = { context.startActivity(Intent(context, LogActivity::class.java)) }) {
                        Icon(Icons.AutoMirrored.Filled.List, contentDescription = "Logcat")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Black,
                    titleContentColor = Color.White
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    val selected = state.apps.filter { it.packageName in state.selectedPackages }
                    when {
                        state.selectedPackages.isEmpty() ->
                            Toast.makeText(context, "Pilih aplikasi dulu", Toast.LENGTH_SHORT).show()
                        selected.any { it.statusBahaya == StatusBahaya.BAHAYA } ->
                            dialogLevel = StatusBahaya.BAHAYA
                        selected.any { it.statusBahaya == StatusBahaya.PERINGATAN } ->
                            dialogLevel = StatusBahaya.PERINGATAN
                        else -> viewModel.executeClearCache(context)
                    }
                },
                icon = { Icon(Icons.Default.Delete, contentDescription = null) },
                text = { Text("Bersihkan Cache") }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Button(
                onClick = { viewModel.onCheckRootClicked() },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text("Cek Akses Root")
            }

            AutoClearCard(state.apps)

            TabRow(
                selectedTabIndex = if (state.isAggressiveMode) 1 else 0,
                containerColor = Color.Black,
                contentColor = MaterialTheme.colorScheme.primary
            ) {
                Tab(
                    selected = !state.isAggressiveMode,
                    onClick = { viewModel.setAggressiveMode(false) },
                    text = { Text("Mode Biasa") }
                )
                Tab(
                    selected = state.isAggressiveMode,
                    onClick = { viewModel.setAggressiveMode(true) },
                    text = { Text("Mode Agresif") }
                )
            }
            Text(
                text = if (state.isAggressiveMode) "Sapu bersih sisa file sementara" else "Hapus cache standar",
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = state.searchQuery,
                    onValueChange = { viewModel.setSearchQuery(it) },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    label = { Text("Cari aplikasi") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) }
                )
                TextButton(onClick = { viewModel.toggleSort() }) {
                    Text(if (state.sortBySize) "Urut: Cache" else "Urut: A-Z")
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    AppFilter.SEMUA to "Semua",
                    AppFilter.PENGGUNA to "Pengguna",
                    AppFilter.SISTEM to "Sistem"
                ).forEach { (filter, label) ->
                    FilterChip(
                        selected = state.filter == filter,
                        onClick = { viewModel.setFilter(filter) },
                        label = { Text(label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF00695C),
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 96.dp),
                verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
            ) {
                items(visibleApps, key = { it.packageName }) { app ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF121212))
                    ) {
                        Row(
                            modifier = Modifier.padding(end = 16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = app.packageName in state.selectedPackages,
                                onCheckedChange = { viewModel.toggleSelection(app.packageName) }
                            )
                            Image(
                                bitmap = remember(app.icon) { app.icon.asImageBitmap() },
                                contentDescription = null,
                                modifier = Modifier.size(40.dp)
                            )
                            Column(modifier = Modifier.padding(start = 12.dp, top = 12.dp, bottom = 12.dp)) {
                                Text(
                                    text = app.nama,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = Color.White
                                )
                                Text(
                                    text = app.packageName,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.Gray
                                )
                                Text(
                                    text = "%.2f MB".format(app.ukuranCache / 1024.0),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AutoClearCard(apps: List<AppInfo>) {
    val context = LocalContext.current
    val manager = remember { AutoClearManager(context) }
    var enabled by remember { mutableStateOf(manager.isEnabled()) }
    var hour by remember { mutableStateOf(manager.getHour()) }
    var minute by remember { mutableStateOf(manager.getMinute()) }
    var selected by remember { mutableStateOf(manager.getPackages()) }
    var showPicker by remember { mutableStateOf(false) }
    var lastRun by remember { mutableStateOf(manager.getLastRun()) }
    var exactOk by remember { mutableStateOf(manager.canScheduleExact()) }

    // Pasang ulang alarm tiap aplikasi dibuka agar jadwal selalu aktif.
    LaunchedEffect(Unit) {
        manager.rescheduleIfEnabled()
        exactOk = manager.canScheduleExact()
    }

    if (showPicker) {
        AutoClearPickerDialog(
            apps = apps,
            initial = selected,
            onDismiss = { showPicker = false },
            onSave = { chosen ->
                selected = chosen
                manager.setPackages(chosen)
                showPicker = false
            }
        )
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 16.dp, bottom = 8.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF121212))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween
            ) {
                Text("Aktifkan Auto-Clear", color = Color.White)
                Switch(
                    checked = enabled,
                    onCheckedChange = { checked ->
                        enabled = checked
                        manager.setEnabled(checked)
                        if (checked) manager.schedule(hour, minute) else manager.cancel()
                        if (checked && selected.isEmpty()) {
                            Toast.makeText(context, "Pilih aplikasi yang mau dibersihkan otomatis", Toast.LENGTH_LONG).show()
                        }
                    }
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween
            ) {
                Text("Jam: %02d:%02d (setiap hari)".format(hour, minute), color = Color.White)
                TextButton(onClick = {
                    TimePickerDialog(
                        context,
                        { _, h, m ->
                            hour = h
                            minute = m
                            manager.setTime(h, m)
                            if (enabled) manager.schedule(h, m)
                        },
                        hour,
                        minute,
                        true
                    ).show()
                }) {
                    Text("Pilih Jam")
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween
            ) {
                Text("Aplikasi: ${selected.size} dipilih", color = Color.White)
                TextButton(onClick = { showPicker = true }) {
                    Text("Pilih Aplikasi")
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween
            ) {
                Text(
                    "Terakhir: ${lastRun ?: "belum pernah"}",
                    color = Color.Gray,
                    style = MaterialTheme.typography.bodySmall
                )
                TextButton(onClick = {
                    manager.runNow()
                    Toast.makeText(context, "Membersihkan aplikasi pilihan...", Toast.LENGTH_SHORT).show()
                }) {
                    Text("Tes Sekarang")
                }
            }
            if (enabled && !exactOk) {
                TextButton(onClick = {
                    runCatching {
                        context.startActivity(
                            Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                                .setData(android.net.Uri.parse("package:${context.packageName}"))
                        )
                    }
                }) {
                    Text("Izinkan alarm tepat waktu (jadwal bisa meleset tanpa ini)")
                }
            }
        }
    }
}

/** Dialog pilih aplikasi untuk auto-clear. Aplikasi kategori Bahaya tidak ditampilkan (aman dari bootloop). */
@Composable
private fun AutoClearPickerDialog(
    apps: List<AppInfo>,
    initial: Set<String>,
    onDismiss: () -> Unit,
    onSave: (Set<String>) -> Unit
) {
    var chosen by remember { mutableStateOf(initial) }
    var query by remember { mutableStateOf("") }
    val candidates = remember(apps, query) {
        apps.filter { it.statusBahaya != StatusBahaya.BAHAYA }
            .filter { query.isBlank() || it.nama.contains(query.trim(), ignoreCase = true) }
            .sortedWith(compareBy({ it.isSystemApp }, { it.nama.lowercase() }))
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF121212),
        titleContentColor = Color.White,
        textContentColor = Color.White,
        title = { Text("Aplikasi Auto-Clear (${chosen.size})") },
        text = {
            Column {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = { Text("Cari aplikasi") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                LazyColumn(modifier = Modifier.padding(top = 8.dp).weight(1f, fill = false)) {
                    items(candidates, key = { it.packageName }) { app ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = app.packageName in chosen,
                                onCheckedChange = { on ->
                                    chosen = if (on) chosen + app.packageName else chosen - app.packageName
                                }
                            )
                            Column(modifier = Modifier.padding(start = 4.dp)) {
                                Text(app.nama, color = Color.White, style = MaterialTheme.typography.bodyMedium)
                                Text(
                                    if (app.isSystemApp) "Sistem" else "Pengguna",
                                    color = Color.Gray,
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onSave(chosen) }) { Text("Simpan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}
