package com.alfy.cleaner

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class AppFilter { SEMUA, PENGGUNA, SISTEM }

data class MainUiState(
    val apps: List<AppInfo> = emptyList(),
    val isRootGranted: Boolean = false,
    val selectedPackages: Set<String> = emptySet(),
    val isAggressiveMode: Boolean = false,
    val searchQuery: String = "",
    val filter: AppFilter = AppFilter.SEMUA,
    val sortBySize: Boolean = false
) {
    /** Daftar yang ditampilkan: sudah difilter (cari + jenis) dan diurutkan. */
    val visibleApps: List<AppInfo>
        get() {
            val query = searchQuery.trim()
            val filtered = apps.filter { app ->
                (query.isEmpty() || app.nama.contains(query, ignoreCase = true)) &&
                    when (filter) {
                        AppFilter.SEMUA -> true
                        AppFilter.PENGGUNA -> !app.isSystemApp
                        AppFilter.SISTEM -> app.isSystemApp
                    }
            }
            return if (sortBySize) {
                filtered.sortedByDescending { it.ukuranCache }
            } else {
                filtered.sortedBy { it.nama.lowercase() }
            }
        }
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val rootManager = RootManager()
    private val scanner = CacheScanner(application)

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 1)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    init {
        viewModelScope.launch(Dispatchers.IO) {
            val apps = scanner.getInstalledApps()
            withContext(Dispatchers.Main) {
                _uiState.update { it.copy(apps = apps) }
            }
        }
    }

    fun toggleSelection(packageName: String) {
        _uiState.update { state ->
            val newSet = if (packageName in state.selectedPackages) {
                state.selectedPackages - packageName
            } else {
                state.selectedPackages + packageName
            }
            state.copy(selectedPackages = newSet)
        }
    }

    fun setSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun setFilter(filter: AppFilter) {
        _uiState.update { it.copy(filter = filter) }
    }

    fun toggleSort() {
        _uiState.update { it.copy(sortBySize = !it.sortBySize) }
    }

    fun setAggressiveMode(aggressive: Boolean) {
        if (_uiState.value.isAggressiveMode == aggressive) return
        _uiState.update { it.copy(isAggressiveMode = aggressive) }

        // Ukuran cache berbeda per mode; hitung ulang jika root sudah diberikan.
        if (_uiState.value.isRootGranted) {
            viewModelScope.launch(Dispatchers.IO) {
                val apps = scanner.scanWithCacheSize(aggressive)
                withContext(Dispatchers.Main) {
                    _uiState.update { it.copy(apps = apps) }
                }
            }
        }
    }

    @Suppress("UNUSED_PARAMETER")
    fun executeClearCache(context: Context) {
        val targets = _uiState.value.selectedPackages.toList()
        val aggressive = _uiState.value.isAggressiveMode
        if (targets.isEmpty()) return

        viewModelScope.launch(Dispatchers.IO) {
            val failed = targets.filterNot {
                if (aggressive) rootManager.clearCacheAggressive(it) else rootManager.clearCache(it)
            }
            val refreshed = scanner.scanWithCacheSize(aggressive)
            withContext(Dispatchers.Main) {
                _uiState.update { it.copy(apps = refreshed, selectedPackages = emptySet()) }
                _messages.tryEmit(
                    if (failed.isEmpty()) "Cache berhasil dibersihkan"
                    else "Gagal membersihkan ${failed.size} aplikasi (cek akses root)"
                )
            }
        }
    }

    fun onCheckRootClicked() {
        viewModelScope.launch(Dispatchers.IO) {
            if (!rootManager.checkRoot()) {
                withContext(Dispatchers.Main) {
                    _uiState.update { it.copy(isRootGranted = false) }
                    _messages.tryEmit("Root tidak ditemukan (su tidak tersedia)")
                }
                return@launch
            }

            val granted = rootManager.requestRoot()
            withContext(Dispatchers.Main) {
                _uiState.update { it.copy(isRootGranted = granted) }
                _messages.tryEmit(if (granted) "Akses root diberikan" else "Akses root ditolak")
            }

            if (granted) {
                val apps = scanner.scanWithCacheSize(_uiState.value.isAggressiveMode)
                withContext(Dispatchers.Main) {
                    _uiState.update { it.copy(apps = apps) }
                }
            }
        }
    }
}
