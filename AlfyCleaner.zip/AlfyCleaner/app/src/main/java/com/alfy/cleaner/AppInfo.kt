package com.alfy.cleaner

import android.graphics.Bitmap

enum class StatusBahaya { AMAN, PERINGATAN, BAHAYA }

data class AppInfo(
    val nama: String,
    val packageName: String,
    val ukuranCache: Long, // dalam KB
    val isSystemApp: Boolean,
    val statusBahaya: StatusBahaya,
    val icon: Bitmap
)
