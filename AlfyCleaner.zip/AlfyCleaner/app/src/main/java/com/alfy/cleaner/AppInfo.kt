package com.alfy.cleaner

enum class StatusBahaya { AMAN, PERINGATAN, BAHAYA }

data class AppInfo(
    val nama: String,
    val packageName: String,
    val ukuranCache: Long, // dalam KB
    val isSystemApp: Boolean,
    val statusBahaya: StatusBahaya
)
