package com.alfy.cleaner

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import java.util.Calendar

/**
 * Auto-clear harian pada jam:menit pilihan, hanya untuk aplikasi yang dipilih.
 * Dijadwalkan lewat AlarmManager (tepat waktu, tahan Doze) -> AutoClearReceiver -> AutoClearWorker.
 * Semua pengaturan (aktif, jam, daftar aplikasi) disimpan di SharedPreferences.
 */
class AutoClearManager(private val context: Context) {

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun isEnabled(): Boolean = prefs.getBoolean(KEY_ENABLED, false)
    fun getHour(): Int = prefs.getInt(KEY_HOUR, DEFAULT_HOUR)
    fun getMinute(): Int = prefs.getInt(KEY_MINUTE, DEFAULT_MINUTE)

    fun setEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_ENABLED, enabled).apply()
    }

    fun setTime(hour: Int, minute: Int) {
        prefs.edit().putInt(KEY_HOUR, hour).putInt(KEY_MINUTE, minute).apply()
    }

    /** Paket yang dipilih untuk dibersihkan otomatis. */
    fun getPackages(): Set<String> = prefs.getStringSet(KEY_PACKAGES, emptySet())?.toSet() ?: emptySet()

    fun setPackages(packages: Set<String>) {
        prefs.edit().putStringSet(KEY_PACKAGES, packages.toSet()).apply()
    }

    /** Ringkasan eksekusi terakhir, mis. "18/11 03:00 - 5 aplikasi" atau null bila belum pernah jalan. */
    fun getLastRun(): String? = prefs.getString(KEY_LAST_RUN, null)

    fun setLastRun(text: String) {
        prefs.edit().putString(KEY_LAST_RUN, text).apply()
    }

    private fun alarmManager() = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    fun canScheduleExact(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S || alarmManager().canScheduleExactAlarms()

    private fun alarmIntent(): PendingIntent = PendingIntent.getBroadcast(
        context,
        0,
        Intent(context, AutoClearReceiver::class.java).setAction(AutoClearReceiver.ACTION_ALARM),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    /** Pasang alarm untuk kemunculan berikutnya dari jam:menit (hari ini bila belum lewat, selain itu besok). */
    fun schedule(hour: Int, minute: Int) {
        val triggerAt = nextTriggerMillis(hour, minute)
        val am = alarmManager()
        val pi = alarmIntent()
        if (canScheduleExact()) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
        } else {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi) // tidak tepat waktu, tapi tetap jalan
        }
    }

    /** Pasang ulang alarm dari pengaturan tersimpan (dipanggil saat app dibuka, boot, atau setelah alarm berbunyi). */
    fun rescheduleIfEnabled() {
        if (isEnabled()) schedule(getHour(), getMinute())
    }

    fun cancel() {
        alarmManager().cancel(alarmIntent())
        WorkManager.getInstance(context).cancelUniqueWork(LEGACY_WORK_NAME)
    }

    /** Jalankan pembersihan sekarang juga (dipakai alarm dan tombol "Bersihkan sekarang"). */
    fun runNow() {
        WorkManager.getInstance(context).enqueueUniqueWork(
            WORK_NAME,
            ExistingWorkPolicy.REPLACE,
            OneTimeWorkRequestBuilder<AutoClearWorker>().build()
        )
    }

    private fun nextTriggerMillis(hour: Int, minute: Int): Long {
        val now = Calendar.getInstance()
        val target = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= now.timeInMillis) add(Calendar.DAY_OF_YEAR, 1)
        }
        return target.timeInMillis
    }

    private companion object {
        const val PREFS_NAME = "alfy_auto_clear"
        const val KEY_ENABLED = "enabled"
        const val KEY_HOUR = "hour"
        const val KEY_MINUTE = "minute"
        const val KEY_PACKAGES = "packages"
        const val KEY_LAST_RUN = "last_run"
        const val DEFAULT_HOUR = 3
        const val DEFAULT_MINUTE = 0
        const val WORK_NAME = "alfy_auto_clear_now"
        const val LEGACY_WORK_NAME = "alfy_auto_clear_work"
    }
}
