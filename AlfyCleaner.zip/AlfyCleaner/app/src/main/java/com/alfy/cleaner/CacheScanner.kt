package com.alfy.cleaner

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import kotlin.math.roundToLong
import androidx.core.graphics.drawable.toBitmap
import com.topjohnwu.superuser.Shell

private const val ICON_SIZE_PX = 96
private const val TAG = "CacheScanner"

class CacheScanner(private val context: Context) {

    private val dangerPackages = setOf(
        "android",
        "com.android.systemui",
        "com.android.phone",
        "com.android.settings",
        "com.android.providers.media",
        "com.android.providers.settings",
        "com.android.inputmethod.latin"
    )

    private val warningPackages = setOf(
        "com.android.vending",
        "com.google.android.gms",
        "com.google.android.gsf"
    )

    /** Daftar aplikasi terinstal via PackageManager (ukuran cache belum dihitung). Blocking. */
    fun getInstalledApps(): List<AppInfo> {
        val pm = context.packageManager
        val infos = if (Build.VERSION.SDK_INT >= 33) {
            pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pm.getInstalledApplications(0)
        }
        return infos.map { info ->
            val isSystem = (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            AppInfo(
                nama = pm.getApplicationLabel(info).toString(),
                packageName = info.packageName,
                ukuranCache = 0L,
                isSystemApp = isSystem,
                statusBahaya = categorize(info.packageName, isSystem),
                icon = runCatching { pm.getApplicationIcon(info.packageName) }
                    .getOrElse { pm.defaultActivityIcon }
                    .toBitmap(ICON_SIZE_PX, ICON_SIZE_PX)
            )
        }.sortedBy { it.packageName }
    }

    /** Daftar aplikasi + ukuran cache via root shell, diurutkan dari terbesar. Blocking. */
    fun scanWithCacheSize(isAggressive: Boolean = false): List<AppInfo> {
        Log.d(TAG, "scanWithCacheSize dimulai (agresif=$isAggressive)")

        // Cek identitas shell: harus UID 0 (root), kalau tidak scan dihentikan.
        val shell = Shell.getShell()
        Log.d(TAG, "Apakah App Granted Root: ${Shell.isAppGrantedRoot()}")
        Log.d(TAG, "Apakah Shell isRoot: ${shell.isRoot}")
        val idResult = Shell.cmd("id").exec()
        Log.d(TAG, "ID Shell: ${idResult.out}")
        if (idResult.out.none { it.contains("uid=0") }) {
            Log.e(TAG, "BUKAN ROOT SEJATI!")
            return getInstalledApps() // daftar tanpa ukuran, agar daftar di UI tidak kosong
        }

        // Diagnostik: apakah folder cache benar-benar terlihat oleh shell root?
        Log.d(TAG, "Cek LS: ${Shell.cmd("ls -la /data/data/com.android.chrome/cache").exec().out}")

        val apps = getInstalledApps()
            .map { it.copy(ukuranCache = getCacheSizeKb(it.packageName, isAggressive)) }
        Log.d(TAG, "scanWithCacheSize selesai: ${apps.size} aplikasi, ${apps.count { it.ukuranCache > 0 }} berukuran > 0 KB")
        return apps.sortedByDescending { it.ukuranCache }
    }

    /** Ukuran cache dalam KB (dipakai AppInfo; UI mengonversi ke MB). Mode agresif menambah code_cache dan cache eksternal. */
    fun getCacheSizeKb(packageName: String, isAggressive: Boolean = false): Long {
        val base = (getCacheSizeRobust(packageName) * 1024.0).roundToLong()
        if (!isAggressive) return base

        val shell = Shell.getShell()
        if (!shell.isRoot) return base
        return base +
            robustKb("/data/data/$packageName/code_cache") +
            robustKb("/sdcard/Android/data/$packageName/cache")
    }

    /**
     * Ukuran folder cache aplikasi dalam MB (Double). Memakai root shell valid (Shell.getShell())
     * dan memakai dua metode: A (libsu) lalu B (Runtime exec su) bila A tidak memberi ukuran > 0. Blocking.
     */
    fun getCacheSizeRobust(packageName: String): Double {
        val shell = Shell.getShell()
        if (!shell.isRoot) {
            Log.e(TAG, "Shell bukan root, tidak bisa membaca cache $packageName")
            Log.e(TAG, "Total gagal untuk $packageName")
            return 0.0
        }

        val kb = robustKb("/data/data/$packageName/cache")
        if (kb <= 0) {
            Log.e(TAG, "Total gagal untuk $packageName")
        }
        return kb / 1024.0
    }

    /** Ukuran satu folder dalam KB: Metode A (libsu), lalu Metode B (Runtime exec su), lalu ls bila gagal. */
    private fun robustKb(path: String): Long {
        val cmd = "du -sk $path"

        // Metode A: libsu
        Log.d(TAG, "Metode A (libsu), mencoba perintah: $cmd")
        val res = Shell.cmd(cmd).exec()
        Log.d(TAG, "Metode A OUT: ${res.out} | ERR: ${res.err}")
        parseLeadingNumber(res.out)?.takeIf { it > 0 }?.let { return it }

        // Metode B: paksa lewat Runtime exec (di luar libsu)
        Log.d(TAG, "Metode B (Runtime exec su), mencoba perintah: $cmd")
        val resultString = runSu(cmd)
        Log.d(TAG, "Hasil Paksa Runtime: $resultString")
        parseLeadingNumber(resultString.lines())?.takeIf { it > 0 }?.let { return it }

        // Kedua metode gagal: lihat isi folder
        val lsResult = Shell.cmd("ls -la $path").exec()
        Log.d(TAG, "LS Folder: ${lsResult.out}")
        return 0L
    }

    /** Jalankan perintah lewat Runtime exec su -c dan kembalikan stdout sebagai String. Blocking. */
    private fun runSu(cmd: String): String =
        try {
            val process = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
            val out = process.inputStream.bufferedReader().use { it.readText() }
            val err = process.errorStream.bufferedReader().use { it.readText() }
            process.waitFor()
            process.destroy()
            if (err.isNotBlank()) Log.d(TAG, "Runtime ERR: $err")
            out.trim()
        } catch (e: Exception) {
            Log.e(TAG, "Runtime exec gagal: ${e.message}")
            ""
        }

    private val leadingNumber = Regex("^\\s*(\\d+)(\\s|\$)")

    /** Ambil angka di awal baris pertama yang cocok; kebal terhadap baris/teks tambahan di keluaran shell. */
    private fun parseLeadingNumber(lines: List<String>): Long? =
        lines.firstNotNullOfOrNull { line ->
            leadingNumber.find(line)?.groupValues?.get(1)?.toLongOrNull()
        }

    private fun categorize(packageName: String, isSystem: Boolean): StatusBahaya = when {
        packageName in dangerPackages -> StatusBahaya.BAHAYA
        packageName in warningPackages -> StatusBahaya.PERINGATAN
        isSystem -> StatusBahaya.PERINGATAN
        else -> StatusBahaya.AMAN
    }
}
