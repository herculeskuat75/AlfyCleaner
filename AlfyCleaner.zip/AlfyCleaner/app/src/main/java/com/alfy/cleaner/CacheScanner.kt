package com.alfy.cleaner

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import kotlin.math.roundToLong
import androidx.core.graphics.drawable.toBitmap
import java.io.InputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking

private const val ICON_SIZE_PX = 96
private const val TAG = "CacheScanner"

class CacheScanner(private val context: Context) {

    private val dangerPackages = setOf(
        "android",
        "com.android.systemui",
        "com.android.phone",
        "com.android.settings",
        "com.android.providers.media",
        "com.android.providers.settings",
        "com.android.inputmethod.latin"
    )

    private val warningPackages = setOf(
        "com.android.vending",
        "com.google.android.gms",
        "com.google.android.gsf"
    )

    /** Daftar aplikasi terinstal via PackageManager (ukuran cache belum dihitung). Blocking. */
    fun getInstalledApps(): List<AppInfo> {
        val pm = context.packageManager
        val infos = if (Build.VERSION.SDK_INT >= 33) {
            pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pm.getInstalledApplications(0)
        }
        return infos.map { info ->
            val isSystem = (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            AppInfo(
                nama = pm.getApplicationLabel(info).toString(),
                packageName = info.packageName,
                ukuranCache = 0L,
                isSystemApp = isSystem,
                statusBahaya = categorize(info.packageName, isSystem),
                icon = runCatching { pm.getApplicationIcon(info.packageName) }
                    .getOrElse { pm.defaultActivityIcon }
                    .toBitmap(ICON_SIZE_PX, ICON_SIZE_PX)
            )
        }.sortedBy { it.packageName }
    }

    /** Daftar aplikasi + ukuran cache via su -M (Runtime.exec), diurutkan dari terbesar. Blocking; dijalankan di Dispatchers.IO. */
    fun scanWithCacheSize(isAggressive: Boolean = false): List<AppInfo> = runBlocking(Dispatchers.IO) {
        Log.d(TAG, "scanWithCacheSize dimulai (agresif=$isAggressive)")

        val idOut = runSu("id")
        Log.d(TAG, "ID Shell (Runtime su -M): $idOut")
        if (!idOut.contains("uid=0")) {
            Log.e(TAG, "BUKAN ROOT SEJATI! Scan dibatalkan.")
            return@runBlocking getInstalledApps() // daftar tanpa ukuran, agar daftar di UI tidak kosong
        }

        val apps = getInstalledApps()
            .map { it.copy(ukuranCache = getCacheSizeKb(it.packageName, isAggressive)) }
        Log.d(TAG, "scanWithCacheSize selesai: ${apps.size} aplikasi, ${apps.count { it.ukuranCache > 0 }} berukuran > 0 KB")
        apps.sortedByDescending { it.ukuranCache }
    }

    /** Ukuran cache dalam KB (dipakai AppInfo; UI mengonversi ke MB). Mode agresif menambah code_cache dan cache eksternal. */
    fun getCacheSizeKb(packageName: String, isAggressive: Boolean = false): Long {
        val base = (getCacheSizeRobust(packageName) * 1024.0).roundToLong()
        if (!isAggressive) return base

        return base +
            robustKb("/data/data/$packageName/code_cache") +
            robustKb("/sdcard/Android/data/$packageName/cache")
    }

    /** Ukuran cache aplikasi dalam MB (Double), hanya dari /data/data/$packageName/cache (/data/user/0 adalah symlink). Blocking. */
    fun getCacheSizeRobust(packageName: String): Double {
        val kb = robustKb("/data/data/$packageName/cache")
        if (kb <= 0) {
            Log.e(TAG, "Ukuran 0/gagal untuk $packageName")
        }
        return kb / 1024.0
    }

    /** Ukuran satu folder dalam KB lewat su -M -c "du -sk". Output kosong atau error (mis. No such file) -> 0. */
    private fun robustKb(path: String): Long {
        val out = runSu("du -sk $path")
        Log.d(TAG, "du $path -> $out")
        if (out.isBlank() || out.contains("No such file", ignoreCase = true)) return 0L
        val parsedKb = parseKb(out)
        Log.d("CacheScanner", "Hasil parsing KB: $parsedKb")
        return parsedKb
    }

    /** Ambil angka paling depan dari output du (mis. "121564 \t /data/..." -> 121564). Regex dulu, lalu split spasi/tab. */
    private fun parseKb(output: String): Long {
        for (line in output.lines()) {
            val t = line.trim()
            val match = Regex("^\\d+").find(t)
            if (match != null) return match.value.toLongOrNull() ?: 0L
        }
        return output.trim().split(Regex("\\s+")).firstOrNull()?.toLongOrNull() ?: 0L
    }

    /** Jalankan perintah lewat Runtime exec su -M -c dan kembalikan stdout sebagai String. Blocking. */
    private fun runSu(cmd: String): String =
        try {
            val process = Runtime.getRuntime().exec(arrayOf("su", "-M", "-c", cmd))
            val out = process.inputStream.toText()
            val err = process.errorStream.toText()
            process.waitFor()
            process.destroy()
            if (err.isNotBlank()) Log.d(TAG, "Runtime ERR: $err")
            out.trim()
        } catch (e: Exception) {
            Log.e(TAG, "Runtime exec gagal: ${e.message}")
            ""
        }

    /** Baca seluruh InputStream menjadi String. */
    private fun InputStream.toText(): String = bufferedReader().use { it.readText() }

    private fun categorize(packageName: String, isSystem: Boolean): StatusBahaya = when {
        packageName in dangerPackages -> StatusBahaya.BAHAYA
        packageName in warningPackages -> StatusBahaya.PERINGATAN
        isSystem -> StatusBahaya.PERINGATAN
        else -> StatusBahaya.AMAN
    }
}
