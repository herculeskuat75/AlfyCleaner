package com.alfy.cleaner

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import com.topjohnwu.superuser.Shell

class CacheScanner(private val context: Context) {

    private val dangerPackages = setOf(
        "android",
        "com.android.systemui",
        "com.android.phone",
        "com.android.settings",
        "com.android.providers.media",
        "com.android.providers.settings",
        "com.android.inputmethod.latin"
    )

    private val warningPackages = setOf(
        "com.android.vending",
        "com.google.android.gms",
        "com.google.android.gsf"
    )

    /** Daftar aplikasi terinstal via PackageManager (ukuran cache belum dihitung). Blocking. */
    fun getInstalledApps(): List<AppInfo> {
        val pm = context.packageManager
        val infos = if (Build.VERSION.SDK_INT >= 33) {
            pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pm.getInstalledApplications(0)
        }
        return infos.map { info ->
            val isSystem = (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            AppInfo(
                nama = pm.getApplicationLabel(info).toString(),
                packageName = info.packageName,
                ukuranCache = 0L,
                isSystemApp = isSystem,
                statusBahaya = categorize(info.packageName, isSystem)
            )
        }.sortedBy { it.packageName }
    }

    /** Daftar aplikasi + ukuran cache via root shell, diurutkan dari terbesar. Blocking. */
    fun scanWithCacheSize(isAggressive: Boolean = false): List<AppInfo> =
        getInstalledApps()
            .map { it.copy(ukuranCache = getCacheSizeKb(it.packageName, isAggressive)) }
            .sortedByDescending { it.ukuranCache }

    /** Ukuran cache (KB) dari /data/data dan /data/user/0; diambil yang terbesar agar symlink tidak terhitung ganda. */
    fun getCacheSizeKb(packageName: String, isAggressive: Boolean = false): Long {
        val base = listOf(
            "/data/data/$packageName/cache",
            "/data/user/0/$packageName/cache"
        ).maxOf { duKb(it) }
        if (!isAggressive) return base

        // Mode agresif: + code_cache dan cache di penyimpanan eksternal
        return base +
            duKb("/data/data/$packageName/code_cache") +
            duKb("/sdcard/Android/data/$packageName/cache")
    }

    private fun duKb(path: String): Long {
        // Shell libsu berjalan sebagai `su`, setara dengan: su -c "du -sk <path>"
        val result = Shell.cmd("du -sk $path 2>/dev/null").exec()
        return result.out.firstOrNull()
            ?.trim()
            ?.split(Regex("\\s+"))
            ?.firstOrNull()
            ?.toLongOrNull() ?: 0L
    }

    private fun categorize(packageName: String, isSystem: Boolean): StatusBahaya = when {
        packageName in dangerPackages -> StatusBahaya.BAHAYA
        packageName in warningPackages -> StatusBahaya.PERINGATAN
        isSystem -> StatusBahaya.PERINGATAN
        else -> StatusBahaya.AMAN
    }
}
