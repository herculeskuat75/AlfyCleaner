package com.alfy.cleaner

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.core.graphics.drawable.toBitmap
import com.topjohnwu.superuser.Shell

private const val ICON_SIZE_PX = 96
private const val TAG = "CacheScanner"

class CacheScanner(private val context: Context) {

    private val dangerPackages = setOf(
        "android",
        "com.android.systemui",
        "com.android.phone",
        "com.android.settings",
        "com.android.providers.media",
        "com.android.providers.settings",
        "com.android.inputmethod.latin"
    )

    private val warningPackages = setOf(
        "com.android.vending",
        "com.google.android.gms",
        "com.google.android.gsf"
    )

    /** Daftar aplikasi terinstal via PackageManager (ukuran cache belum dihitung). Blocking. */
    fun getInstalledApps(): List<AppInfo> {
        val pm = context.packageManager
        val infos = if (Build.VERSION.SDK_INT >= 33) {
            pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pm.getInstalledApplications(0)
        }
        return infos.map { info ->
            val isSystem = (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            AppInfo(
                nama = pm.getApplicationLabel(info).toString(),
                packageName = info.packageName,
                ukuranCache = 0L,
                isSystemApp = isSystem,
                statusBahaya = categorize(info.packageName, isSystem),
                icon = runCatching { pm.getApplicationIcon(info.packageName) }
                    .getOrElse { pm.defaultActivityIcon }
                    .toBitmap(ICON_SIZE_PX, ICON_SIZE_PX)
            )
        }.sortedBy { it.packageName }
    }

    /** Daftar aplikasi + ukuran cache via root shell, diurutkan dari terbesar. Blocking. */
    fun scanWithCacheSize(isAggressive: Boolean = false): List<AppInfo> =
        getInstalledApps()
            .map { it.copy(ukuranCache = getCacheSizeKb(it.packageName, isAggressive)) }
            .sortedByDescending { it.ukuranCache }

    /** Ukuran cache (KB) dari /data/data dan /data/user/0; diambil yang terbesar agar symlink tidak terhitung ganda. */
    fun getCacheSizeKb(packageName: String, isAggressive: Boolean = false): Long {
        val base = listOf(
            "/data/data/$packageName/cache",
            "/data/user/0/$packageName/cache"
        ).maxOf { duKb(it) }
        if (!isAggressive) return base

        // Mode agresif: + code_cache dan cache di penyimpanan eksternal
        return base +
            duKb("/data/data/$packageName/code_cache") +
            duKb("/sdcard/Android/data/$packageName/cache")
    }

    private val leadingNumber = Regex("^\\s*(\\d+)(\\s|\$)")

    /** Ambil angka di awal baris pertama yang cocok; kebal terhadap baris/teks tambahan di keluaran shell. */
    private fun parseLeadingNumber(lines: List<String>): Long? =
        lines.firstNotNullOfOrNull { line ->
            leadingNumber.find(line)?.groupValues?.get(1)?.toLongOrNull()
        }

    private fun bytesToKb(bytes: Long): Long = (bytes + 1023L) / 1024L

    /** Ukuran folder dalam KB via `du -sk` (shell libsu berjalan sebagai su); fallback ke find + stat bila gagal. */
    private fun duKb(path: String): Long {
        val result = Shell.cmd("du -sk $path").exec()
        val err = result.err
        if (err.isNotEmpty()) {
            Log.e(TAG, "Error: ${err.joinToString(" | ")}")
        }

        parseLeadingNumber(result.out)?.let { return it }

        // Jika FLAG_REDIRECT_STDERR aktif, pesan error ikut masuk ke out.
        val allText = result.out + err
        if (allText.any { it.contains("No such file", ignoreCase = true) }) {
            return 0L // folder cache memang tidak ada
        }
        if (allText.isNotEmpty()) {
            Log.e(TAG, "Error: du gagal untuk $path -> ${allText.joinToString(" | ")}")
        }
        return fallbackSizeKb(path)
    }

    /** Fallback: jumlahkan ukuran file (byte) dengan find + stat, hasil dikonversi ke KB. */
    private fun fallbackSizeKb(path: String): Long {
        // Metode 1: find + stat + awk
        val awk = Shell.cmd(
            "find $path -type f -exec stat -c %s {} + | awk '{s+=\$1} END {print s}'"
        ).exec()
        if (awk.err.isNotEmpty()) {
            Log.e(TAG, "Error: ${awk.err.joinToString(" | ")}")
        }
        parseLeadingNumber(awk.out)?.let { return bytesToKb(it) }

        // Metode 2 (tanpa awk, mis. awk tidak tersedia): jumlahkan keluaran stat di Kotlin
        val stat = Shell.cmd("find $path -type f -exec stat -c %s {} +").exec()
        if (stat.err.isNotEmpty()) {
            Log.e(TAG, "Error: ${stat.err.joinToString(" | ")}")
        }
        val totalBytes = stat.out.sumOf { it.trim().toLongOrNull() ?: 0L }
        return bytesToKb(totalBytes)
    }

    private fun categorize(packageName: String, isSystem: Boolean): StatusBahaya = when {
        packageName in dangerPackages -> StatusBahaya.BAHAYA
        packageName in warningPackages -> StatusBahaya.PERINGATAN
        isSystem -> StatusBahaya.PERINGATAN
        else -> StatusBahaya.AMAN
    }
}
