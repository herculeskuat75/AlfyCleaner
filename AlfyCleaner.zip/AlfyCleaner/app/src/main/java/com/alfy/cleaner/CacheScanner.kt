package com.alfy.cleaner

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import kotlin.math.roundToLong
import androidx.core.graphics.drawable.toBitmap
import com.topjohnwu.superuser.Shell

private const val ICON_SIZE_PX = 96
private const val TAG = "CacheScanner"

class CacheScanner(private val context: Context) {

    private val dangerPackages = setOf(
        "android",
        "com.android.systemui",
        "com.android.phone",
        "com.android.settings",
        "com.android.providers.media",
        "com.android.providers.settings",
        "com.android.inputmethod.latin"
    )

    private val warningPackages = setOf(
        "com.android.vending",
        "com.google.android.gms",
        "com.google.android.gsf"
    )

    /** Daftar aplikasi terinstal via PackageManager (ukuran cache belum dihitung). Blocking. */
    fun getInstalledApps(): List<AppInfo> {
        val pm = context.packageManager
        val infos = if (Build.VERSION.SDK_INT >= 33) {
            pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pm.getInstalledApplications(0)
        }
        return infos.map { info ->
            val isSystem = (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            AppInfo(
                nama = pm.getApplicationLabel(info).toString(),
                packageName = info.packageName,
                ukuranCache = 0L,
                isSystemApp = isSystem,
                statusBahaya = categorize(info.packageName, isSystem),
                icon = runCatching { pm.getApplicationIcon(info.packageName) }
                    .getOrElse { pm.defaultActivityIcon }
                    .toBitmap(ICON_SIZE_PX, ICON_SIZE_PX)
            )
        }.sortedBy { it.packageName }
    }

    /** Daftar aplikasi + ukuran cache via root shell, diurutkan dari terbesar. Blocking. */
    fun scanWithCacheSize(isAggressive: Boolean = false): List<AppInfo> {
        Log.d(TAG, "scanWithCacheSize dimulai (agresif=$isAggressive)")
        val apps = getInstalledApps()
            .map { it.copy(ukuranCache = getCacheSizeKb(it.packageName, isAggressive)) }
        Log.d(TAG, "scanWithCacheSize selesai: ${apps.size} aplikasi, ${apps.count { it.ukuranCache > 0 }} berukuran > 0 KB")
        return apps.sortedByDescending { it.ukuranCache }
    }

    /** Ukuran cache dalam KB (dipakai AppInfo; UI mengonversi ke MB). Mode agresif menambah code_cache dan cache eksternal. */
    fun getCacheSizeKb(packageName: String, isAggressive: Boolean = false): Long {
        val base = (getCacheSizeRobust(packageName) * 1024.0).roundToLong()
        if (!isAggressive) return base

        val shell = Shell.getShell()
        if (!shell.isRoot) return base
        return base +
            robustKb(shell, "/data/data/$packageName/code_cache") +
            robustKb(shell, "/sdcard/Android/data/$packageName/cache")
    }

    /**
     * Ukuran folder cache aplikasi dalam MB (Double). Memakai root shell valid (Shell.getShell())
     * dan mencoba beberapa perintah secara berurutan: du -sk, toybox du -sk, find + stat. Blocking.
     */
    fun getCacheSizeRobust(packageName: String): Double {
        val shell = Shell.getShell()
        if (!shell.isRoot) {
            Log.e(TAG, "Shell bukan root, tidak bisa membaca cache $packageName")
            Log.e(TAG, "Total gagal untuk $packageName")
            return 0.0
        }

        var kb = 0L
        for (path in listOf("/data/data/$packageName/cache", "/data/user/0/$packageName/cache")) {
            kb = robustKb(shell, path)
            if (kb > 0) break
        }
        if (kb <= 0) {
            Log.e(TAG, "Total gagal untuk $packageName")
        }
        return kb / 1024.0
    }

    /** Coba perintah satu per satu untuk satu path; kembalikan KB pertama yang > 0, atau 0 bila semua gagal. */
    private fun robustKb(shell: Shell, path: String): Long {
        // Pair(perintah, true = keluaran du dalam KB | false = daftar ukuran file dalam byte)
        val commands = listOf(
            "du -sk $path" to true,
            "toybox du -sk $path" to true,
            "find $path -type f -exec stat -c %s {} +" to false,
            "find $path -type f -exec stat -c %s {} \\;" to false
        )

        for ((cmd, isDu) in commands) {
            Log.d(TAG, "Mencoba perintah: $cmd")
            val res = shell.newJob().add(cmd).exec()
            Log.d(TAG, "Hasil OUT: ${res.out} | ERR: ${res.err}")

            val kb = if (isDu) parseLeadingNumber(res.out) else sumBytesToKb(res.out)
            if (kb != null && kb > 0) return kb

            // Folder memang tidak ada: perintah lain pasti gagal juga.
            if ((res.out + res.err).any { it.contains("No such file", ignoreCase = true) }) return 0L
        }
        return 0L
    }

    private val leadingNumber = Regex("^\\s*(\\d+)(\\s|\$)")

    /** Ambil angka di awal baris pertama yang cocok; kebal terhadap baris/teks tambahan di keluaran shell. */
    private fun parseLeadingNumber(lines: List<String>): Long? =
        lines.firstNotNullOfOrNull { line ->
            leadingNumber.find(line)?.groupValues?.get(1)?.toLongOrNull()
        }

    /** Jumlahkan baris numerik (byte per file), abaikan baris lain, lalu ubah ke KB. */
    private fun sumBytesToKb(lines: List<String>): Long? {
        val sizes = lines.mapNotNull { it.trim().toLongOrNull() }
        return if (sizes.isEmpty()) null else (sizes.sum() + 1023L) / 1024L
    }

    private fun categorize(packageName: String, isSystem: Boolean): StatusBahaya = when {
        packageName in dangerPackages -> StatusBahaya.BAHAYA
        packageName in warningPackages -> StatusBahaya.PERINGATAN
        isSystem -> StatusBahaya.PERINGATAN
        else -> StatusBahaya.AMAN
    }
}
