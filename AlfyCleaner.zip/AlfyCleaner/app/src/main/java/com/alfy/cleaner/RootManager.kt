package com.alfy.cleaner

import com.topjohnwu.superuser.Shell
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class RootManager {

    /**
     * Cek akses root sekaligus memicu pop-up Superuser (KernelSU/Magisk) lewat Shell.getShell().
     * Mengembalikan true jika izin diberikan, false jika ditolak atau su tidak tersedia.
     */
    suspend fun checkRoot(): Boolean = withContext(Dispatchers.IO) {
        // Shell non-root yang tersimpan dari percobaan sebelumnya dibuang agar pop-up muncul lagi.
        val cached = Shell.getCachedShell()
        if (cached != null && !cached.isRoot) {
            runCatching { cached.close() }
        }
        Shell.getShell().isRoot
    }

    /** Meminta izin root (memunculkan pop-up Superuser). Blocking: panggil dari Dispatchers.IO. */
    fun requestRoot(): Boolean {
        val cached = Shell.getCachedShell()
        if (cached != null && !cached.isRoot) {
            runCatching { cached.close() }
        }
        return Shell.getShell().isRoot
    }

    /**
     * Menghapus ISI folder cache (bukan foldernya). Blocking: panggil dari Dispatchers.IO.
     * Shell libsu berjalan sebagai `su`, setara dengan perintah su -c rm -rf pada isi folder cache.
     */
    fun clearCache(packageName: String): Boolean {
        val r1 = Shell.cmd("rm -rf /data/data/$packageName/cache/*").exec()
        val r2 = Shell.cmd("rm -rf /data/user/0/$packageName/cache/*").exec()
        return r1.isSuccess && r2.isSuccess
    }

    /**
     * Pembersihan agresif: isi cache, code_cache, cache eksternal, serta file berekstensi tmp dan log.
     * Folder `databases` dan `shared_prefs` TIDAK PERNAH disentuh (di-prune oleh find,
     * ditambah filter -path sebagai pengaman kedua; `rm` hanya menyasar isi folder cache).
     * Blocking: panggil dari Dispatchers.IO.
     */
    fun clearCacheAggressive(packageName: String): Boolean {
        // Pengaman: nama package kosong/aneh dapat membuat path melebar ke seluruh /data/data.
        if (!Regex("^[A-Za-z0-9_.]+$").matches(packageName)) return false

        val rm = Shell.cmd(
            "rm -rf /data/data/$packageName/cache/* " +
                "/data/data/$packageName/code_cache/* " +
                "/sdcard/Android/data/$packageName/cache/*"
        ).exec()

        val find = Shell.cmd(
            "find /data/data/$packageName " +
                "\\( -name databases -o -name shared_prefs \\) -prune -o " +
                "-type f \\( -name '*.tmp' -o -name '*.log' \\) " +
                "! -path '*/databases/*' ! -path '*/shared_prefs/*' " +
                "-exec rm -f {} +"
        ).exec()

        return rm.isSuccess && find.isSuccess
    }
}
