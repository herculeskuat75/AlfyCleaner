package com.alfy.cleaner

import com.topjohnwu.superuser.Shell
import java.io.File

class RootManager {

    /** Cek apakah binary `su` tersedia (tidak memunculkan pop-up Superuser). */
    fun checkRoot(): Boolean {
        val dirs = listOf(
            "/system/bin", "/system/xbin", "/sbin", "/vendor/bin",
            "/system/sbin", "/su/bin", "/product/bin", "/apex/com.android.runtime/bin"
        )
        return dirs.any { File(it, "su").exists() }
    }

    /** Meminta izin root (memunculkan pop-up Superuser). Blocking: panggil dari Dispatchers.IO. */
    fun requestRoot(): Boolean {
        val cached = Shell.getCachedShell()
        if (cached != null && !cached.isRoot) {
            runCatching { cached.close() }
        }
        return Shell.getShell().isRoot
    }

    /**
     * Menghapus ISI folder cache (bukan foldernya). Blocking: panggil dari Dispatchers.IO.
     * Shell libsu berjalan sebagai `su`, setara dengan: su -c "rm -rf /data/data/<pkg>/cache/*"
     */
    fun clearCache(packageName: String): Boolean {
        val r1 = Shell.cmd("rm -rf /data/data/$packageName/cache/*").exec()
        val r2 = Shell.cmd("rm -rf /data/user/0/$packageName/cache/*").exec()
        return r1.isSuccess && r2.isSuccess
    }

    /**
     * Pembersihan agresif: isi cache, code_cache, cache eksternal, serta file *.tmp / *.log.
     * Folder `databases` dan `shared_prefs` TIDAK PERNAH disentuh (di-prune oleh find,
     * ditambah filter -path sebagai pengaman kedua; `rm` hanya menyasar isi folder cache).
     * Blocking: panggil dari Dispatchers.IO.
     */
    fun clearCacheAggressive(packageName: String): Boolean {
        // Pengaman: nama package kosong/aneh dapat membuat path melebar ke seluruh /data/data.
        if (!Regex("^[A-Za-z0-9_.]+$").matches(packageName)) return false

        val rm = Shell.cmd(
            "rm -rf /data/data/$packageName/cache/* " +
                "/data/data/$packageName/code_cache/* " +
                "/sdcard/Android/data/$packageName/cache/*"
        ).exec()

        val find = Shell.cmd(
            "find /data/data/$packageName " +
                "\\( -name databases -o -name shared_prefs \\) -prune -o " +
                "-type f \\( -name '*.tmp' -o -name '*.log' \\) " +
                "! -path '*/databases/*' ! -path '*/shared_prefs/*' " +
                "-exec rm -f {} +"
        ).exec()

        return rm.isSuccess && find.isSuccess
    }
}
