package com.alfy.cleaner

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Menerima alarm jadwal (jalankan pembersihan + jadwalkan besok) dan boot/update (pasang ulang alarm). */
class AutoClearReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val manager = AutoClearManager(context)
        if (!manager.isEnabled()) return
        when (intent.action) {
            ACTION_ALARM -> {
                manager.rescheduleIfEnabled() // alarm sekali jalan: pasang untuk hari berikutnya
                manager.runNow()
            }
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED -> manager.rescheduleIfEnabled()
        }
    }

    companion object {
        const val ACTION_ALARM = "com.alfy.cleaner.ACTION_AUTO_CLEAR"
    }
}
