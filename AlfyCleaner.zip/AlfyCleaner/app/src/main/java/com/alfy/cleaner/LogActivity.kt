package com.alfy.cleaner

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.topjohnwu.superuser.Shell
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val LogColors = darkColorScheme(
    primary = Color(0xFF80CBC4),
    onPrimary = Color.Black,
    background = Color.Black,
    onBackground = Color.White,
    surface = Color.Black,
    onSurface = Color.White
)

// Shell libsu berjalan sebagai su, setara dengan: su -c "logcat -d -s CacheScanner:* ..."
// Format "brief" dipakai agar baris diawali "E/", "W/", "I/".
private const val LOG_COMMAND =
    "logcat -d -v brief -s 'CacheScanner:*' 'RootManager:*' 'AutoClearWorker:*'"

class LogActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = LogColors) {
                LogScreen(onBack = { finish() })
            }
        }
    }
}

private suspend fun readLog(): List<String> = withContext(Dispatchers.IO) {
    val result = Shell.cmd(LOG_COMMAND).exec()
    (result.out + result.err).filter { it.isNotBlank() }
}

private fun lineColor(line: String): Color = when {
    line.startsWith("E/") -> Color(0xFFFF5252)
    line.startsWith("W/") -> Color(0xFFFFEB3B)
    line.startsWith("I/") -> Color(0xFF69F0AE)
    else -> Color(0xFFB0BEC5)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LogScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    var lines by remember { mutableStateOf<List<String>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }

    fun refresh() {
        scope.launch {
            loading = true
            lines = readLog()
            loading = false
        }
    }

    LaunchedEffect(Unit) { refresh() }

    // Setelah log dimuat, gulir ke baris terbaru (paling bawah).
    LaunchedEffect(lines) {
        if (lines.isNotEmpty()) listState.scrollToItem(lines.lastIndex)
    }

    Scaffold(
        containerColor = Color.Black,
        topBar = {
            TopAppBar(
                title = { Text("Logcat") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Black,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(onClick = { refresh() }) { Text("Refresh") }
                Button(onClick = {
                    if (lines.isEmpty()) {
                        Toast.makeText(context, "Log kosong", Toast.LENGTH_SHORT).show()
                    } else {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("AlfyCleaner Log", lines.joinToString("\n")))
                        Toast.makeText(context, "Log disalin", Toast.LENGTH_SHORT).show()
                    }
                }) { Text("Copy Log") }
            }

            when {
                loading && lines.isEmpty() -> Text(
                    text = "Memuat log...",
                    color = Color.Gray,
                    modifier = Modifier.padding(16.dp)
                )
                lines.isEmpty() -> Text(
                    text = "Belum ada log untuk CacheScanner, RootManager, atau AutoClearWorker.",
                    color = Color.Gray,
                    modifier = Modifier.padding(16.dp)
                )
                else -> LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    items(lines) { line ->
                        Text(
                            text = line,
                            color = lineColor(line),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}
