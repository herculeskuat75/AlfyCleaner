package com.alfy.cleaner

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Membersihkan cache aplikasi pilihan dengan cara yang sama seperti tombol "Bersihkan Cache" (mode biasa). */
class AutoClearWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val manager = AutoClearManager(applicationContext)
        val stamp = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date())

        val selected = manager.getPackages()
        if (selected.isEmpty()) {
            manager.setLastRun("$stamp - tidak ada aplikasi dipilih")
            return@withContext Result.success()
        }

        val rootManager = RootManager()
        if (!rootManager.requestRoot()) {
            Log.e(TAG, "Auto-clear gagal: root tidak tersedia")
            manager.setLastRun("$stamp - gagal (root ditolak)")
            return@withContext Result.success()
        }

        // Hanya aplikasi yang masih terinstal dan bukan kategori Bahaya (agar tidak bootloop).
        val targets = CacheScanner(applicationContext)
            .getInstalledApps()
            .filter { it.packageName in selected && it.statusBahaya != StatusBahaya.BAHAYA }

        val ok = targets.count { rootManager.clearCache(it.packageName) }
        Log.d(TAG, "Auto-clear: $ok/${targets.size} aplikasi dibersihkan")
        manager.setLastRun("$stamp - $ok/${targets.size} aplikasi")
        Result.success()
    }

    private companion object {
        const val TAG = "AutoClearWorker"
    }
}
