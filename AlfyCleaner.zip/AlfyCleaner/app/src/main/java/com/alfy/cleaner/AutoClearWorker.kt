package com.alfy.cleaner

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AutoClearWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val rootManager = RootManager()
        if (!rootManager.requestRoot()) return@withContext Result.success()

        // Hanya kategori Aman & Peringatan; Bahaya dilewati agar tidak bootloop.
        CacheScanner(applicationContext)
            .getInstalledApps()
            .filter { it.statusBahaya != StatusBahaya.BAHAYA }
            .forEach { rootManager.clearCache(it.packageName) }

        Result.success()
    }
}
